mvn compile exec:java -Dexec.mainClass=demo.EmployeeDbDemo
